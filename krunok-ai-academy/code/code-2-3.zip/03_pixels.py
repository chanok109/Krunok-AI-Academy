import cv2

img = cv2.imread("fruits.png")
if img is None:
    print("เปิดภาพไม่ได้ ตรวจชื่อไฟล์และโฟลเดอร์")
    raise SystemExit

# อ่านค่าสี 1 พิกเซล ตำแหน่ง (y, x) บนแอปเปิลแดง
y, x = 600, 420
print("ก่อนแก้ B G R =", img[y, x])

# แก้ 1 พิกเซลให้เป็นสีน้ำเงิน
img[y, x] = [255, 0, 0]
print("หลังแก้ B G R =", img[y, x])

# แก้ทีละหลายพิกเซล: แถว 50 ถึง 149 คอลัมน์ 900 ถึง 1199 ให้เป็นสีเหลือง
img[50:150, 900:1200] = [0, 255, 255]
print("ขนาดพื้นที่ที่แก้:", img[50:150, 900:1200].shape)

cv2.imshow("Edited", img)
cv2.waitKey(0)
cv2.destroyAllWindows()

cv2.imwrite("fruits_edit.png", img)
print("บันทึก fruits_edit.png แล้ว")
