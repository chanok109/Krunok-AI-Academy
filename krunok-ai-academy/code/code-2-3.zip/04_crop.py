import cv2

img = cv2.imread("fruits.png")
if img is None:
    print("เปิดภาพไม่ได้ ตรวจชื่อไฟล์และโฟลเดอร์")
    raise SystemExit

# ตัดภาพ = เลือกช่วงแถวและคอลัมน์ img[y1:y2, x1:x2]
crop = img[400:800, 260:660]

print("ภาพเดิม:", img.shape)
print("ภาพที่ตัด:", crop.shape)

cv2.imshow("Crop", crop)
cv2.waitKey(0)
cv2.destroyAllWindows()

cv2.imwrite("apple_crop.png", crop)
print("บันทึก apple_crop.png แล้ว")
