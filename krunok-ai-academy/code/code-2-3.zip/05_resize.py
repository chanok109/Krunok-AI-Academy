import cv2

img = cv2.imread("fruits.png")
if img is None:
    print("เปิดภาพไม่ได้ ตรวจชื่อไฟล์และโฟลเดอร์")
    raise SystemExit

# แบบที่ 1 กำหนดขนาดใหม่เป็น (กว้าง, สูง)
small = cv2.resize(img, (640, 410))

# แบบที่ 2 กำหนดเป็นสัดส่วน 0.5 เท่า ทั้งแนวนอนและแนวตั้ง
half = cv2.resize(img, None, fx=0.5, fy=0.5)

# แบบที่ 3 ไม่รักษาสัดส่วน ภาพจะยืดหรือบีบ
wide = cv2.resize(img, (1275, 400))

print("ภาพเดิม:", img.shape)
print("small:", small.shape)
print("half:", half.shape)
print("wide:", wide.shape)

cv2.imshow("Small", small)
cv2.imshow("Wide", wide)
cv2.waitKey(0)
cv2.destroyAllWindows()

cv2.imwrite("fruits_small.png", small)
print("บันทึก fruits_small.png แล้ว")
