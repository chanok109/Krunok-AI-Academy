import cv2

img = cv2.imread("fruits.png")
if img is None:
    print("เปิดภาพไม่ได้ ตรวจชื่อไฟล์และโฟลเดอร์")
    raise SystemExit

h = cv2.flip(img, 1)     # 1  = พลิกซ้าย-ขวา (เหมือนกระจก)
v = cv2.flip(img, 0)     # 0  = พลิกบน-ล่าง
both = cv2.flip(img, -1) # -1 = พลิกทั้งสองแบบ (หมุน 180 องศา)

height, width = img.shape[:2]
y, x = 600, 420
print("ภาพเดิม       img[600, 420] =", img[y, x])
print("พลิกซ้าย-ขวา  h[600, 854]   =", h[y, width - 1 - x])
print("พลิกบน-ล่าง   v[216, 420]   =", v[height - 1 - y, x])

cv2.imshow("Flip 1", h)
cv2.imshow("Flip 0", v)
cv2.imshow("Flip -1", both)
cv2.waitKey(0)
cv2.destroyAllWindows()

cv2.imwrite("fruits_flip.png", h)
print("บันทึก fruits_flip.png แล้ว")
