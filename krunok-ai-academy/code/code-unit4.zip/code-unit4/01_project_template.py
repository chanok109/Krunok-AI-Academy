# แม่แบบโครงงาน AI: กล้อง → โมเดล → ตัดสินใจ → แสดงผล → บันทึก
import cv2
import csv
import time
from ultralytics import YOLO

# ===== 1) ตั้งค่าโครงงาน (แก้ส่วนนี้) =====
MODEL = "runs/classify/emoji/weights/best.pt"   # โมเดลของกลุ่ม หรือ "yolo11n.pt" สำหรับตรวจจับวัตถุ
CLASSES = ["happy", "sad", "surprised"]         # ประเภทที่โมเดลรู้จัก (กดปุ่ม 1, 2, 3 = คำตอบที่ถูกตอนทดสอบ)
MIN_CONF = 0.7                                   # มั่นใจน้อยกว่านี้ ถือว่า "ไม่แน่ใจ"
SOURCE = 0                                       # 0 = กล้อง หรือใส่ชื่อไฟล์วิดีโอ

def decide(label, conf):
    # ===== 2) กติกาของโครงงาน: เปลี่ยนคำตอบของโมเดลเป็นการกระทำ =====
    if conf < MIN_CONF:
        return "uncertain - show again"
    if label == "happy":
        return "Great! keep smiling"
    if label == "sad":
        return "Take a break?"
    return "Wow!"

model = YOLO(MODEL)
cap = cv2.VideoCapture(SOURCE)
if not cap.isOpened():
    print("เปิดกล้องหรือวิดีโอไม่ได้")
    raise SystemExit

log = open("test_log.csv", "a", newline="")       # ===== 3) บันทึกผลทดสอบ =====
writer = csv.writer(log)
tested = 0
print("กด 1 ถึง", len(CLASSES), "บอกคำตอบที่ถูกเพื่อบันทึกผลทดสอบ กด q เพื่อออก")

while True:
    ok, frame = cap.read()
    if not ok:
        break
    t = time.time()
    r = model(frame, verbose=False)[0]
    if r.probs is not None:                       # โมเดลจำแนกภาพ
        label, conf = r.names[r.probs.top1], float(r.probs.top1conf)
    elif len(r.boxes) > 0:                        # โมเดลตรวจจับวัตถุ ใช้กรอบที่มั่นใจที่สุด
        best = r.boxes[int(r.boxes.conf.argmax())]
        label, conf = r.names[int(best.cls)], float(best.conf)
    else:
        label, conf = "none", 0.0
    action = decide(label, conf)
    fps = 1 / max(time.time() - t, 1e-6)

    cv2.putText(frame, f"{label} {conf:.2f}", (10, 35), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 200, 0), 2)
    cv2.putText(frame, action, (10, 75), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 0, 255), 2)
    cv2.putText(frame, f"FPS {fps:.1f}  tested {tested}", (10, frame.shape[0] - 15),
                cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2)
    cv2.imshow("AI Project", frame)

    key = cv2.waitKey(1) & 0xFF
    if key == ord("q"):
        break
    for i, c in enumerate(CLASSES):
        if key == ord(str(i + 1)):                # กดคำตอบที่ถูก → บันทึกคู่ (คำตอบจริง, โมเดลทาย)
            writer.writerow([c, label, round(conf, 3)])
            tested = tested + 1

log.close()
cap.release()
cv2.destroyAllWindows()
print("บันทึกผลทดสอบเพิ่ม", tested, "ครั้ง ลงไฟล์ test_log.csv")
