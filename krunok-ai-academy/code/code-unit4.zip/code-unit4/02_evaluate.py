import csv
from sklearn.metrics import accuracy_score, confusion_matrix, classification_report

CLASSES = ["happy", "sad", "surprised"]
y_true, y_pred = [], []
with open("test_log.csv") as f:
    for true, pred, conf in csv.reader(f):
        y_true.append(true)
        y_pred.append(pred)

print("จำนวนครั้งที่ทดสอบ:", len(y_true))
print("ความแม่นยำ:", round(accuracy_score(y_true, y_pred), 3))
print("ตารางความสับสน", CLASSES)
print(confusion_matrix(y_true, y_pred, labels=CLASSES))
print(classification_report(y_true, y_pred, labels=CLASSES, zero_division=0))
