import cv2

cap = cv2.VideoCapture("balls.mp4")     # ใส่ชื่อไฟล์แทนเลขกล้อง
if not cap.isOpened():
    print("เปิดวิดีโอไม่ได้ ตรวจชื่อไฟล์และโฟลเดอร์")
    raise SystemExit

fps = cap.get(cv2.CAP_PROP_FPS)
total = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
w = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
h = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
print("ขนาดเฟรม:", w, "x", h)
print("FPS:", fps)
print("จำนวนเฟรม:", total)
print("ความยาว:", total / fps, "วินาที")

delay = int(1000 / fps)                 # 30 FPS รอเฟรมละ 33 มิลลิวินาที
count = 0
while True:
    ok, frame = cap.read()
    if not ok:                          # อ่านจนหมดไฟล์ ok จะเป็น False
        break
    count = count + 1
    cv2.imshow("Video", frame)
    if cv2.waitKey(delay) & 0xFF == ord("q"):
        break

cap.release()
cv2.destroyAllWindows()
print("เล่นจบแล้ว อ่านได้", count, "เฟรม")
