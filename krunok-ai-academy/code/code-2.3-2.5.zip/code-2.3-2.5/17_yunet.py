import cv2

# 1) โหลดโมเดล YuNet (ไฟล์ .onnx ต้องอยู่ในโฟลเดอร์เดียวกับโค้ด)
img = cv2.imread("faces.png")
if img is None:
    print("เปิดภาพไม่ได้ ตรวจชื่อไฟล์และโฟลเดอร์")
    raise SystemExit
h, w = img.shape[:2]
detector = cv2.FaceDetectorYN.create(
    "face_detection_yunet_2023mar.onnx", "",
    (w, h),                 # ขนาดภาพที่จะตรวจ (กว้าง, สูง)
    score_threshold=0.5)    # คะแนนความมั่นใจขั้นต่ำ 0 ถึง 1

# 2) ตรวจจับใบหน้า ใช้ภาพสีได้เลย ไม่ต้องแปลงเป็นภาพเทา
ok, faces = detector.detect(img)
if faces is None:
    print("ไม่พบใบหน้า")
    raise SystemExit
print("พบใบหน้า", len(faces), "หน้า")

# 3) แต่ละแถวมี 15 ค่า: x, y, w, h, จุดสำคัญ 5 จุด (10 ค่า), คะแนนความมั่นใจ
n = 0
for f in faces:
    n = n + 1
    x, y, fw, fh = f[:4].astype(int)
    score = f[14]
    print("หน้าที่", n, ": x =", x, " y =", y, " คะแนน =", round(float(score), 2))
    cv2.rectangle(img, (x, y), (x + fw, y + fh), (255, 120, 0), 3)
    for i in range(5):                                 # ตา 2 จุด จมูก 1 จุด มุมปาก 2 จุด
        px, py = int(f[4 + i * 2]), int(f[5 + i * 2])
        cv2.circle(img, (px, py), 4, (0, 0, 255), -1)
    cv2.putText(img, str(round(float(score), 2)), (x, y - 8), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 120, 0), 2)

cv2.imshow("YuNet", img)
cv2.waitKey(0)
cv2.destroyAllWindows()
cv2.imwrite("faces_yunet.png", img)
print("บันทึก faces_yunet.png แล้ว")
