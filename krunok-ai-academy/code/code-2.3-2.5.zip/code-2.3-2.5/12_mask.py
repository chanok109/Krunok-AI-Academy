import cv2
import numpy as np

img = cv2.imread("fruits.png")
if img is None:
    print("เปิดภาพไม่ได้ ตรวจชื่อไฟล์และโฟลเดอร์")
    raise SystemExit
hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)

# สีส้ม: H อยู่ในช่วงเดียว
lower = np.array([11, 150, 150])              # [H, S, V] ต่ำสุด
upper = np.array([25, 255, 255])              # [H, S, V] สูงสุด
mask_orange = cv2.inRange(hsv, lower, upper)  # อยู่ในช่วง = 255 (ขาว) นอกช่วง = 0 (ดำ)

# สีแดง: อยู่ทั้งต้นวงล้อ (0-10) และท้ายวงล้อ (170-179) ต้องใช้ 2 ช่วงแล้วรวมกัน
mask1 = cv2.inRange(hsv, np.array([0, 120, 70]), np.array([10, 255, 255]))
mask2 = cv2.inRange(hsv, np.array([170, 120, 70]), np.array([179, 255, 255]))
mask_red = cv2.bitwise_or(mask1, mask2)

# เก็บเฉพาะพิกเซลที่ mask เป็นสีขาว ที่เหลือเป็นสีดำ
orange_only = cv2.bitwise_and(img, img, mask=mask_orange)
red_only = cv2.bitwise_and(img, img, mask=mask_red)

print("mask shape:", mask_orange.shape)
print("ค่าที่มีใน mask:", np.unique(mask_orange))
print("พิกเซลสีส้ม:", cv2.countNonZero(mask_orange))
print("พิกเซลสีแดง:", cv2.countNonZero(mask_red))

cv2.imshow("Mask orange", mask_orange)
cv2.imshow("Orange only", orange_only)
cv2.imshow("Red only", red_only)
cv2.waitKey(0)
cv2.destroyAllWindows()
cv2.imwrite("orange_only.png", orange_only)
cv2.imwrite("red_only.png", red_only)
print("บันทึก orange_only.png และ red_only.png แล้ว")
