import cv2

face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + "haarcascade_frontalface_default.xml")
cap = cv2.VideoCapture(0)
if face_cascade.empty() or not cap.isOpened():
    print("โหลด Haar Cascade หรือเปิดกล้องไม่ได้")
    raise SystemExit

print("กด b เพื่อเปิด/ปิดการเบลอใบหน้า กด q เพื่อออก")
blur = False
while True:
    ok, frame = cap.read()
    if not ok:
        break
    frame = cv2.flip(frame, 1)                            # พลิกให้เหมือนส่องกระจก
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    faces = face_cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=5, minSize=(60, 60))

    if blur:                                              # เบลอใบหน้าทุกหน้าก่อน เพื่อปกป้องความเป็นส่วนตัว
        for (x, y, w, h) in faces:
            face = frame[y:y + h, x:x + w]
            frame[y:y + h, x:x + w] = cv2.GaussianBlur(face, (51, 51), 0)
    for (x, y, w, h) in faces:                            # แล้วจึงวาดกรอบ
        cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 200, 0), 2)

    cv2.putText(frame, "Faces: " + str(len(faces)), (20, 40), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 255), 2)
    cv2.imshow("Face Detection", frame)

    key = cv2.waitKey(1) & 0xFF
    if key == ord("b"):
        blur = not blur
    if key == ord("q"):
        break

cap.release()
cv2.destroyAllWindows()
