import cv2

cap = cv2.VideoCapture(0)          # 0 = กล้องตัวแรกของเครื่อง
if not cap.isOpened():
    print("เปิดกล้องไม่ได้ ลองเปลี่ยนเป็น 1 หรือปิดโปรแกรมอื่นที่ใช้กล้องอยู่")
    raise SystemExit

w = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
h = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
print("เปิดกล้องแล้ว ขนาดเฟรม", w, "x", h)
print("กด q ที่หน้าต่างภาพเพื่อปิดกล้อง")

count = 0
while True:
    ok, frame = cap.read()         # อ่าน 1 เฟรม ได้ ok (True/False) และภาพ frame
    if not ok:
        print("อ่านเฟรมไม่ได้")
        break
    count = count + 1
    cv2.imshow("Camera", frame)
    if cv2.waitKey(1) & 0xFF == ord("q"):   # รอ 1 มิลลิวินาที ถ้ากด q ให้ออกจากลูป
        break

cap.release()                      # คืนกล้องให้ระบบ
cv2.destroyAllWindows()            # ปิดหน้าต่างทั้งหมด
print("อ่านไปทั้งหมด", count, "เฟรม ปิดกล้องแล้ว")
