import cv2

img = cv2.imread("fruits.png")
if img is None:
    print("เปิดภาพไม่ได้ ตรวจชื่อไฟล์และโฟลเดอร์")
    raise SystemExit

hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)    # แปลง BGR เป็น HSV
print("ขนาด hsv:", hsv.shape)

# แอปเปิลแดง 2 จุด: ส่วนที่โดนแสง และส่วนที่อยู่ในเงา
print("แอปเปิลส่วนสว่าง BGR =", img[520, 330], " HSV =", hsv[520, 330])
print("แอปเปิลส่วนในเงา BGR =", img[760, 450], " HSV =", hsv[760, 450])

h, s, v = cv2.split(hsv)                      # แยก 3 ช่อง H S V
cv2.imshow("H (Hue)", h)
cv2.imshow("S (Saturation)", s)
cv2.imshow("V (Value)", v)
cv2.waitKey(0)
cv2.destroyAllWindows()
