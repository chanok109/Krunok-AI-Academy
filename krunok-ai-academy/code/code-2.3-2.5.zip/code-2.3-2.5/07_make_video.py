import cv2
import numpy as np

# สร้างวิดีโอตัวอย่าง balls.mp4 ขนาด 640 x 360 เล่น 30 เฟรมต่อวินาที ยาว 150 เฟรม (5 วินาที)
fps = 30
size = (640, 360)                          # (กว้าง, สูง)
fourcc = cv2.VideoWriter_fourcc(*"mp4v")
out = cv2.VideoWriter("balls.mp4", fourcc, fps, size)

for i in range(150):
    frame = np.full((360, 640, 3), (238, 232, 226), dtype=np.uint8)
    red_x = 40 + i * 4                                  # ลูกบอลแดงเลื่อนไปทางขวา
    red_y = 110 + int(50 * np.sin(i / 8))
    green_x = 600 - i * 3                               # ลูกบอลเขียวเลื่อนไปทางซ้าย
    yellow_y = 290 - int(abs(120 * np.sin(i / 12)))     # ลูกบอลเหลืองเด้งขึ้นลง
    cv2.circle(frame, (red_x, red_y), 32, (40, 40, 220), -1)
    cv2.circle(frame, (green_x, 270), 28, (60, 180, 40), -1)
    cv2.circle(frame, (320, yellow_y), 24, (30, 210, 250), -1)
    out.write(frame)

out.release()
print("สร้าง balls.mp4 แล้ว 150 เฟรม")
