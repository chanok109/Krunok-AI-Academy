import cv2
import numpy as np

cap = cv2.VideoCapture(0)            # ใช้กล้อง หรือเปลี่ยนเป็น "balls.mp4" เพื่อลองกับวิดีโอ
if not cap.isOpened():
    print("เปิดกล้องไม่ได้")
    raise SystemExit

# ช่วงสีแดง 2 ช่วง (ปรับตัวเลขให้เข้ากับวัตถุและแสงในห้อง)
lower1, upper1 = np.array([0, 120, 70]), np.array([10, 255, 255])
lower2, upper2 = np.array([170, 120, 70]), np.array([179, 255, 255])

found_frames = 0
while True:
    ok, frame = cap.read()
    if not ok:
        break
    hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
    mask = cv2.bitwise_or(cv2.inRange(hsv, lower1, upper1),
                          cv2.inRange(hsv, lower2, upper2))
    result = cv2.bitwise_and(frame, frame, mask=mask)

    pixels = cv2.countNonZero(mask)
    if pixels > 500:                                  # มีสีแดงมากพอ ถือว่าพบวัตถุ
        found_frames = found_frames + 1
        x, y, w, h = cv2.boundingRect(mask)           # กรอบที่ครอบพิกเซลสีขาวทั้งหมด
        cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 255, 0), 3)
        cv2.putText(frame, "RED " + str(pixels) + " px", (x, y - 10),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)

    cv2.imshow("Camera", frame)
    cv2.imshow("Mask", mask)
    cv2.imshow("Result", result)
    if cv2.waitKey(1) & 0xFF == ord("q"):
        break

cap.release()
cv2.destroyAllWindows()
print("พบสีแดงใน", found_frames, "เฟรม")
