import cv2

# 1) โหลดไฟล์ Haar Cascade ที่มากับ OpenCV
path = cv2.data.haarcascades + "haarcascade_frontalface_default.xml"
face_cascade = cv2.CascadeClassifier(path)
if face_cascade.empty():
    print("โหลดไฟล์ Haar Cascade ไม่ได้")
    raise SystemExit

# 2) อ่านภาพและแปลงเป็นภาพเทา (Haar ใช้ความสว่าง ไม่ใช้สี)
img = cv2.imread("faces.png")
if img is None:
    print("เปิดภาพไม่ได้ ตรวจชื่อไฟล์และโฟลเดอร์")
    raise SystemExit
gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

# 3) ตรวจจับใบหน้า ได้รายการกรอบ (x, y, w, h)
faces = face_cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=5, minSize=(40, 40))
print("พบใบหน้า", len(faces), "หน้า")

# 4) วาดกรอบและใส่หมายเลข
n = 0
for (x, y, w, h) in faces:
    n = n + 1
    print("หน้าที่", n, ": x =", x, " y =", y, " w =", w, " h =", h)
    cv2.rectangle(img, (x, y), (x + w, y + h), (0, 200, 0), 3)
    cv2.putText(img, str(n), (x + 5, y + 30), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 200, 0), 2)

cv2.putText(img, "Faces: " + str(len(faces)), (20, 40), cv2.FONT_HERSHEY_SIMPLEX, 1.2, (0, 0, 255), 3)
cv2.imshow("Faces", img)
cv2.waitKey(0)
cv2.destroyAllWindows()
cv2.imwrite("faces_detected.png", img)
print("บันทึก faces_detected.png แล้ว")
