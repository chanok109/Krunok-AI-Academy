import cv2

cap = cv2.VideoCapture("balls.mp4")
if not cap.isOpened():
    print("เปิดวิดีโอไม่ได้ ตรวจชื่อไฟล์และโฟลเดอร์")
    raise SystemExit

fps = cap.get(cv2.CAP_PROP_FPS)
w = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
h = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))

fourcc = cv2.VideoWriter_fourcc(*"mp4v")        # รหัสวิธีบีบอัดไฟล์ .mp4
out = cv2.VideoWriter("balls_gray.mp4", fourcc, fps, (w, h))   # ขนาดใส่ (กว้าง, สูง)

count = 0
while True:
    ok, frame = cap.read()
    if not ok:
        break
    count = count + 1
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)     # ประมวลผล: แปลงเป็นภาพเทา
    gray = cv2.cvtColor(gray, cv2.COLOR_GRAY2BGR)      # กลับเป็น 3 ช่องสีเพื่อบันทึก
    cv2.putText(gray, "frame " + str(count), (20, 40),
                cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 255), 2)
    out.write(gray)                                    # เขียนเฟรมลงไฟล์
    cv2.imshow("Processing", gray)
    if cv2.waitKey(1) & 0xFF == ord("q"):
        break

cap.release()
out.release()                                          # ต้องปิดไฟล์ ไม่เช่นนั้นไฟล์อาจเปิดไม่ได้
cv2.destroyAllWindows()
print("บันทึก balls_gray.mp4 แล้ว", count, "เฟรม")
