import cv2
import numpy as np

# วาดภาพการ์ตูนใบหน้า faces.png ขนาด 960 x 540 สำหรับทดลองตรวจจับใบหน้า
def draw_face(img, cx, cy, s, skin, hair):
    shade = tuple(int(c * 0.6) for c in skin)                                    # สีเงา
    cv2.ellipse(img, (cx, cy), (s, int(s * 1.3)), 0, 0, 360, skin, -1)          # หน้า
    cv2.ellipse(img, (cx, cy - int(s * 0.9)), (int(s * 1.05), int(s * 0.6)), 0, 180, 360, hair, -1)  # ผม
    ey = cy - int(s * 0.25)
    for side in (-1, 1):
        ex = cx + side * int(s * 0.42)
        cv2.ellipse(img, (ex, ey), (int(s * 0.32), int(s * 0.2)), 0, 0, 360, shade, -1)               # เบ้าตา
        cv2.ellipse(img, (ex, ey - int(s * 0.3)), (int(s * 0.3), int(s * 0.07)), 0, 0, 360, hair, -1)  # คิ้ว
        cv2.ellipse(img, (ex, ey), (int(s * 0.13), int(s * 0.07)), 0, 0, 360, (250, 250, 250), -1)    # ตาขาว
        cv2.circle(img, (ex, ey), int(s * 0.07), (30, 25, 25), -1)                                    # ตาดำ
    nose = np.array([[cx, ey + int(s * 0.05)], [cx - int(s * 0.12), cy + int(s * 0.35)],
                     [cx + int(s * 0.1), cy + int(s * 0.38)]])
    cv2.fillPoly(img, [nose], shade)                                                                  # จมูก
    cv2.ellipse(img, (cx, cy + int(s * 0.7)), (int(s * 0.35), int(s * 0.12)), 0, 0, 360, (60, 50, 150), -1)  # ปาก

bg = (236, 240, 244)
img = np.full((540, 960, 3), bg, dtype=np.uint8)
draw_face(img, 120, 300, 78, (150, 190, 230), (40, 40, 60))
draw_face(img, 330, 250, 95, (120, 160, 210), (30, 30, 30))
draw_face(img, 540, 310, 62, (170, 205, 240), (40, 70, 120))
draw_face(img, 700, 240, 48, (110, 150, 200), (25, 25, 25))

# ใบหน้าที่เอียงมาก วาดแยกแล้วหมุน 40 องศา
tilt = np.full((300, 300, 3), bg, dtype=np.uint8)
draw_face(tilt, 150, 160, 70, (140, 180, 225), (50, 50, 70))
m = cv2.getRotationMatrix2D((150, 150), 40, 1)
tilt = cv2.warpAffine(tilt, m, (300, 300), borderValue=bg)
area = img[240:540, 660:960]
keep = np.any(tilt != bg, axis=2)
area[keep] = tilt[keep]

# วัตถุที่ไม่ใช่ใบหน้า
cv2.circle(img, (880, 80), 45, (0, 200, 255), -1)                    # ลูกบอลสีเหลือง
cv2.rectangle(img, (440, 40), (580, 130), (200, 120, 60), -1)        # กล่องสีฟ้า
img = cv2.GaussianBlur(img, (5, 5), 0)
cv2.imwrite("faces.png", img)
print("สร้าง faces.png แล้ว")
