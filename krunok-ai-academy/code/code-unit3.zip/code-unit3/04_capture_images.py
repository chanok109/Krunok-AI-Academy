import cv2
import os

# ชื่อประเภทที่ต้องการสอน (แก้ได้) กดปุ่ม 1, 2, 3 เพื่อถ่ายภาพเก็บเป็นประเภทนั้น
classes = ["happy", "sad", "surprised"]
for split in ["train", "val"]:
    for c in classes:
        os.makedirs(os.path.join("dataset", split, c), exist_ok=True)

cap = cv2.VideoCapture(0)
if not cap.isOpened():
    print("เปิดกล้องไม่ได้")
    raise SystemExit

count = {c: 0 for c in classes}
print("กด 1 ถึง", len(classes), "เพื่อบันทึกภาพ กด q เพื่อออก")
while True:
    ok, frame = cap.read()
    if not ok:
        break
    show = frame.copy()
    for i, c in enumerate(classes):
        cv2.putText(show, str(i + 1) + " " + c + ": " + str(count[c]), (10, 30 + i * 30),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 255, 0), 2)
    cv2.imshow("Capture", show)

    key = cv2.waitKey(1) & 0xFF
    if key == ord("q"):
        break
    for i, c in enumerate(classes):
        if key == ord(str(i + 1)):
            count[c] = count[c] + 1
            split = "val" if count[c] % 5 == 0 else "train"     # ทุกภาพที่ 5 แยกไว้ตรวจสอบ
            path = os.path.join("dataset", split, c, c + "_" + str(count[c]) + ".jpg")
            cv2.imwrite(path, frame)

cap.release()
cv2.destroyAllWindows()
print("จำนวนภาพที่บันทึก:", count)
