import cv2
import time
import joblib
import numpy as np
import mediapipe as mp
from mediapipe.tasks import python as mp_tasks
from mediapipe.tasks.python import vision

options = vision.HandLandmarkerOptions(
    base_options=mp_tasks.BaseOptions(model_asset_path="hand_landmarker.task"),
    running_mode=vision.RunningMode.VIDEO, num_hands=1)
detector = vision.HandLandmarker.create_from_options(options)
clf = joblib.load("hand_model.pkl")

def to_features(pts):
    pts = np.array(pts, dtype=float)
    size = np.linalg.norm(pts[9] - pts[0])
    return ((pts - pts[0]) / size).flatten()

cap = cv2.VideoCapture(0)
start = time.time()
while True:
    ok, frame = cap.read()
    if not ok:
        break
    frame = cv2.flip(frame, 1)
    h, w = frame.shape[:2]
    image = mp.Image(image_format=mp.ImageFormat.SRGB, data=cv2.cvtColor(frame, cv2.COLOR_BGR2RGB))
    result = detector.detect_for_video(image, int((time.time() - start) * 1000))
    if result.hand_landmarks:
        pts = [(p.x * w, p.y * h) for p in result.hand_landmarks[0]]
        feat = to_features(pts)
        label = clf.predict([feat])[0]
        prob = clf.predict_proba([feat]).max()
        for x, y in pts:
            cv2.circle(frame, (int(x), int(y)), 4, (0, 200, 255), -1)
        cv2.putText(frame, f"{label} {prob:.2f}", (10, 40),
                    cv2.FONT_HERSHEY_SIMPLEX, 1.2, (0, 0, 255), 3)
    cv2.imshow("Hand Classifier", frame)
    if cv2.waitKey(1) & 0xFF == ord("q"):
        break

detector.close()
cap.release()
cv2.destroyAllWindows()
