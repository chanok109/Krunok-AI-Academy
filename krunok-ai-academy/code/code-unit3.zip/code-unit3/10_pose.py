import cv2
from ultralytics import YOLO

# โมเดลประมาณท่าทาง หาจุดสำคัญของร่างกาย 17 จุดต่อคน
model = YOLO("yolo11n-pose.pt")
r = model("bus.jpg", verbose=False)[0]

names = ["จมูก", "ตาซ้าย", "ตาขวา", "หูซ้าย", "หูขวา", "ไหล่ซ้าย", "ไหล่ขวา",
         "ศอกซ้าย", "ศอกขวา", "ข้อมือซ้าย", "ข้อมือขวา", "สะโพกซ้าย", "สะโพกขวา",
         "เข่าซ้าย", "เข่าขวา", "ข้อเท้าซ้าย", "ข้อเท้าขวา"]

kp = r.keypoints.xy              # ตำแหน่ง (x, y) รูปร่าง (จำนวนคน, 17, 2)
print("พบคน", len(kp), "คน  รูปร่างข้อมูล:", tuple(kp.shape))
person = kp[0]                   # คนแรก
for i in [0, 5, 6, 9, 10]:
    x, y = person[i].int().tolist()
    print(f"  {i:2d} {names[i]:10s} ({x}, {y})")

cv2.imshow("Pose", r.plot())
cv2.waitKey(0)
cv2.destroyAllWindows()
cv2.imwrite("bus_pose.jpg", r.plot())
