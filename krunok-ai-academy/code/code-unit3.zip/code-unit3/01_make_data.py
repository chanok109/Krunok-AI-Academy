import csv
import numpy as np

# สร้างข้อมูลผลไม้ 90 ลูก: ค่าสี H (จาก HSV) น้ำหนัก (กรัม) และชื่อผลไม้ (ป้ายกำกับ)
rng = np.random.default_rng(7)
kinds = [("ส้ม", 16, 3, 180, 25),
         ("มะนาว", 30, 4, 70, 15),
         ("แอปเปิลเขียว", 38, 4, 170, 25)]   # (ชื่อ, H เฉลี่ย, H แกว่ง, น้ำหนักเฉลี่ย, น้ำหนักแกว่ง)

rows = []
for name, h, hs, w, ws in kinds:
    for i in range(30):
        hue = int(np.clip(rng.normal(h, hs), 0, 179))
        weight = int(rng.normal(w, ws))
        rows.append([hue, weight, name])
rng.shuffle(rows)

with open("fruits_data.csv", "w", newline="", encoding="utf-8-sig") as f:
    writer = csv.writer(f)
    writer.writerow(["hue", "weight", "label"])
    writer.writerows(rows)
print("สร้าง fruits_data.csv แล้ว", len(rows), "แถว")
print("5 แถวแรก:", rows[:5])
