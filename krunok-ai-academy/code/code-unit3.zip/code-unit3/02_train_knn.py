import csv
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import accuracy_score, confusion_matrix

# 1) อ่านข้อมูล: X = ลักษณะ (features)  y = ป้ายกำกับ (labels)
X, y = [], []
with open("fruits_data.csv", encoding="utf-8-sig") as f:
    for row in csv.DictReader(f):
        X.append([int(row["hue"]), int(row["weight"])])
        y.append(row["label"])
X = np.array(X)
y = np.array(y)
print("ข้อมูลทั้งหมด:", X.shape)

# 2) แบ่งข้อมูล 70% ไว้ฝึก 30% ไว้ทดสอบ
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.3, random_state=42, stratify=y)
print("ชุดฝึก:", len(X_train), " ชุดทดสอบ:", len(X_test))

# 3) ฝึกโมเดล k-NN ดูเพื่อนบ้านที่ใกล้ที่สุด 3 ตัว
model = KNeighborsClassifier(n_neighbors=3)
model.fit(X_train, y_train)

# 4) ทดสอบกับข้อมูลที่โมเดลไม่เคยเห็น
pred = model.predict(X_test)
print("ความแม่นยำ:", round(accuracy_score(y_test, pred), 3))
names = ["ส้ม", "มะนาว", "แอปเปิลเขียว"]
print("ตารางความสับสน (แถว = คำตอบจริง, คอลัมน์ = โมเดลทาย)", names)
print(confusion_matrix(y_test, pred, labels=names))

# 5) ใช้โมเดลทายผลไม้ลูกใหม่
new_fruit = [[33, 160]]
print("ผลไม้ H = 33 หนัก 160 กรัม คือ", model.predict(new_fruit)[0])

# ลองใช้ลักษณะเดียว (เฉพาะค่าสี H) เทียบกัน
model_h = KNeighborsClassifier(n_neighbors=3).fit(X_train[:, :1], y_train)
print("ใช้แค่ค่าสี H ความแม่นยำ:", round(accuracy_score(y_test, model_h.predict(X_test[:, :1])), 3))
