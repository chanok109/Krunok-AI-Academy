import cv2
import joblib
import numpy as np
from ultralytics import YOLO

model = YOLO("yolo11n-pose.pt")
clf = joblib.load("pose_model.pkl")

def to_features(kp):
    hip = (kp[11] + kp[12]) / 2
    shoulder = (kp[5] + kp[6]) / 2
    size = np.linalg.norm(shoulder - hip)
    return ((kp - hip) / size).flatten()

cap = cv2.VideoCapture(0)
while True:
    ok, frame = cap.read()
    if not ok:
        break
    r = model(frame, verbose=False)[0]
    show = r.plot()
    if len(r.keypoints.xy) > 0:
        feat = to_features(r.keypoints.xy[0].numpy())
        label = clf.predict([feat])[0]
        prob = clf.predict_proba([feat]).max()          # สัดส่วนเพื่อนบ้านที่โหวตท่านี้
        cv2.putText(show, f"{label} {prob:.2f}", (10, 40),
                    cv2.FONT_HERSHEY_SIMPLEX, 1.2, (0, 0, 255), 3)
    cv2.imshow("Pose Classifier", show)
    if cv2.waitKey(1) & 0xFF == ord("q"):
        break

cap.release()
cv2.destroyAllWindows()
