import csv
import joblib
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import accuracy_score, confusion_matrix

X, y = [], []
with open("pose_data.csv") as f:
    for row in csv.DictReader(f):
        y.append(row["label"])
        X.append([float(row["f" + str(i)]) for i in range(34)])
X, y = np.array(X), np.array(y)
labels, counts = np.unique(y, return_counts=True)
print("ข้อมูล:", X.shape, {str(a): int(b) for a, b in zip(labels, counts)})

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.25, random_state=42, stratify=y)
model = KNeighborsClassifier(n_neighbors=5)
model.fit(X_train, y_train)
pred = model.predict(X_test)
print("ความแม่นยำ:", round(accuracy_score(y_test, pred), 3))
names = ["stand", "right_up", "both_up", "t_pose"]
print("ตารางความสับสน", names)
print(confusion_matrix(y_test, pred, labels=names))

joblib.dump(model, "pose_model.pkl")      # บันทึกโมเดลไว้ใช้กับกล้อง
print("บันทึก pose_model.pkl แล้ว")
