import cv2
import csv
import os
import time
import numpy as np
import mediapipe as mp
from mediapipe.tasks import python as mp_tasks
from mediapipe.tasks.python import vision

gestures = ["fist", "open", "peace", "point", "thumb_up"]    # กด 1 ถึง 5 เพื่อบันทึกท่ามือ

options = vision.HandLandmarkerOptions(
    base_options=mp_tasks.BaseOptions(model_asset_path="hand_landmarker.task"),
    running_mode=vision.RunningMode.VIDEO, num_hands=1)
detector = vision.HandLandmarker.create_from_options(options)

def to_features(pts):
    # ย้ายจุดกำเนิดไปที่ข้อมือ (จุด 0) แล้วหารด้วยระยะข้อมือถึงโคนนิ้วกลาง (จุด 9)
    pts = np.array(pts, dtype=float)
    size = np.linalg.norm(pts[9] - pts[0])
    return ((pts - pts[0]) / size).flatten()                 # 21 จุด x 2 = 42 ตัวเลข

new_file = not os.path.exists("hand_data.csv")
f = open("hand_data.csv", "a", newline="")
writer = csv.writer(f)
if new_file:
    writer.writerow(["label"] + ["f" + str(i) for i in range(42)])

cap = cv2.VideoCapture(0)
count = {g: 0 for g in gestures}
start = time.time()
while True:
    ok, frame = cap.read()
    if not ok:
        break
    frame = cv2.flip(frame, 1)
    h, w = frame.shape[:2]
    image = mp.Image(image_format=mp.ImageFormat.SRGB, data=cv2.cvtColor(frame, cv2.COLOR_BGR2RGB))
    result = detector.detect_for_video(image, int((time.time() - start) * 1000))
    pts = None
    if result.hand_landmarks:
        pts = [(p.x * w, p.y * h) for p in result.hand_landmarks[0]]
        for x, y in pts:
            cv2.circle(frame, (int(x), int(y)), 4, (0, 200, 255), -1)
    for i, g in enumerate(gestures):
        cv2.putText(frame, f"{i + 1} {g}: {count[g]}", (10, 30 + 28 * i),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.75, (0, 255, 0), 2)
    cv2.imshow("Collect", frame)

    key = cv2.waitKey(1) & 0xFF
    if key == ord("q"):
        break
    for i, g in enumerate(gestures):
        if key == ord(str(i + 1)) and pts is not None:
            writer.writerow([g] + [round(float(v), 4) for v in to_features(pts)])
            count[g] = count[g] + 1

f.close()
detector.close()
cap.release()
cv2.destroyAllWindows()
print("บันทึกเพิ่ม:", count)
