import cv2
from ultralytics import YOLO

# โมเดลตรวจจับวัตถุที่ฝึกไว้แล้วกับชุดข้อมูล COCO 80 ประเภท
model = YOLO("yolo11n.pt")
r = model("bus.jpg", conf=0.25, verbose=False)[0]

print("พบวัตถุ", len(r.boxes), "ชิ้น")
for box in r.boxes:
    name = r.names[int(box.cls)]                 # ชื่อประเภท
    conf = float(box.conf)                       # ความมั่นใจ 0 ถึง 1
    x1, y1, x2, y2 = box.xyxy[0].int().tolist()  # มุมซ้ายบน และมุมขวาล่าง
    print(f"  {name:8s} {conf:.2f}  ({x1}, {y1}) ถึง ({x2}, {y2})")

cv2.imshow("Detect", r.plot())
cv2.waitKey(0)
cv2.destroyAllWindows()
cv2.imwrite("bus_detect.jpg", r.plot())
