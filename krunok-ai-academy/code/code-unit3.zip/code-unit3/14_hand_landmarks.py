import cv2
import time
import mediapipe as mp
from mediapipe.tasks import python as mp_tasks
from mediapipe.tasks.python import vision

# เส้นเชื่อมจุดสำคัญ 21 จุดของมือ
LINKS = [(0, 1), (1, 2), (2, 3), (3, 4), (0, 5), (5, 6), (6, 7), (7, 8), (5, 9), (9, 10), (10, 11),
         (11, 12), (9, 13), (13, 14), (14, 15), (15, 16), (13, 17), (17, 18), (18, 19), (19, 20), (0, 17)]

options = vision.HandLandmarkerOptions(
    base_options=mp_tasks.BaseOptions(model_asset_path="hand_landmarker.task"),
    running_mode=vision.RunningMode.VIDEO,    # โหมดวิดีโอ ใช้กับกล้อง
    num_hands=2)
detector = vision.HandLandmarker.create_from_options(options)

cap = cv2.VideoCapture(0)
start = time.time()
while True:
    ok, frame = cap.read()
    if not ok:
        break
    frame = cv2.flip(frame, 1)
    h, w = frame.shape[:2]
    rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)              # MediaPipe ใช้ภาพ RGB
    image = mp.Image(image_format=mp.ImageFormat.SRGB, data=rgb)
    result = detector.detect_for_video(image, int((time.time() - start) * 1000))

    for hand in result.hand_landmarks:                         # มือแต่ละข้าง มี 21 จุด
        pts = [(int(p.x * w), int(p.y * h)) for p in hand]     # x, y เป็นสัดส่วน 0 ถึง 1 ต้องคูณขนาดภาพ
        for a, b in LINKS:
            cv2.line(frame, pts[a], pts[b], (0, 200, 255), 2)
        for i, p in enumerate(pts):
            cv2.circle(frame, p, 5, (0, 0, 255) if i in (4, 8, 12, 16, 20) else (255, 255, 255), -1)

    cv2.putText(frame, "hands: " + str(len(result.hand_landmarks)), (10, 30),
                cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)
    cv2.imshow("Hand Landmarks", frame)
    if cv2.waitKey(1) & 0xFF == ord("q"):
        break

detector.close()
cap.release()
cv2.destroyAllWindows()
