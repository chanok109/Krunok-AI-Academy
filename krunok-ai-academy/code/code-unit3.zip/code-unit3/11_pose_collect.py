import cv2
import csv
import os
import numpy as np
from ultralytics import YOLO

poses = ["stand", "right_up", "both_up", "t_pose"]      # กด 1 ถึง 4 เพื่อบันทึกท่า
model = YOLO("yolo11n-pose.pt")

def to_features(kp):
    # ย้ายจุดกำเนิดไปกึ่งกลางสะโพก แล้วหารด้วยความยาวลำตัว
    # ยืนใกล้หรือไกลกล้องจะได้ตัวเลขใกล้เคียงกัน
    hip = (kp[11] + kp[12]) / 2
    shoulder = (kp[5] + kp[6]) / 2
    size = np.linalg.norm(shoulder - hip)
    return ((kp - hip) / size).flatten()                 # 17 จุด x 2 = 34 ตัวเลข

new_file = not os.path.exists("pose_data.csv")
f = open("pose_data.csv", "a", newline="")
writer = csv.writer(f)
if new_file:
    writer.writerow(["label"] + ["f" + str(i) for i in range(34)])

cap = cv2.VideoCapture(0)
count = {p: 0 for p in poses}
while True:
    ok, frame = cap.read()
    if not ok:
        break
    r = model(frame, verbose=False)[0]
    show = r.plot()
    for i, p in enumerate(poses):
        cv2.putText(show, f"{i + 1} {p}: {count[p]}", (10, 30 + 30 * i),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 255, 0), 2)
    cv2.imshow("Collect", show)

    key = cv2.waitKey(1) & 0xFF
    if key == ord("q"):
        break
    for i, p in enumerate(poses):
        if key == ord(str(i + 1)) and len(r.keypoints.xy) > 0:
            kp = r.keypoints.xy[0].numpy()               # ใช้คนแรกในภาพ
            writer.writerow([p] + [round(float(v), 4) for v in to_features(kp)])
            count[p] = count[p] + 1

f.close()
cap.release()
cv2.destroyAllWindows()
print("บันทึกเพิ่ม:", count)
