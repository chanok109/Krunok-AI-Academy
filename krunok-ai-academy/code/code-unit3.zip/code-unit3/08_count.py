from ultralytics import YOLO

model = YOLO("yolo11n.pt")

# ลองเปลี่ยนค่า conf แล้วดูว่าจำนวนวัตถุเปลี่ยนอย่างไร
for c in [0.1, 0.25, 0.5, 0.8]:
    r = model("bus.jpg", conf=c, verbose=False)[0]
    print("conf =", c, " พบ", len(r.boxes), "ชิ้น")

# เลือกเฉพาะคน (หมายเลขประเภท 0 = person) แล้วนับ
r = model("bus.jpg", conf=0.25, classes=[0], verbose=False)[0]
print("จำนวนคนในภาพ:", len(r.boxes))

# นับแยกตามประเภท
r = model("bus.jpg", conf=0.25, verbose=False)[0]
count = {}
for box in r.boxes:
    name = r.names[int(box.cls)]
    count[name] = count.get(name, 0) + 1
print("นับแยกประเภท:", count)
