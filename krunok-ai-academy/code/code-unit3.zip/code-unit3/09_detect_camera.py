import cv2
import time
from ultralytics import YOLO

model = YOLO("yolo11n.pt")
cap = cv2.VideoCapture(0)
if not cap.isOpened():
    print("เปิดกล้องไม่ได้")
    raise SystemExit

while True:
    ok, frame = cap.read()
    if not ok:
        break
    t = time.time()
    r = model(frame, conf=0.5, verbose=False)[0]
    fps = 1 / (time.time() - t)                       # ประมวลผลได้กี่เฟรมต่อวินาที
    people = sum(1 for b in r.boxes if int(b.cls) == 0)
    out = r.plot()
    cv2.putText(out, f"people: {people}  FPS: {fps:.1f}", (10, 30),
                cv2.FONT_HERSHEY_SIMPLEX, 0.9, (0, 0, 255), 2)
    cv2.imshow("YOLO Camera", out)
    if cv2.waitKey(1) & 0xFF == ord("q"):
        break

cap.release()
cv2.destroyAllWindows()
