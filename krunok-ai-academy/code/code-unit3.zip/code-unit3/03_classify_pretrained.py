import cv2
from ultralytics import YOLO

# โมเดลจำแนกภาพที่ฝึกไว้แล้วกับภาพ ImageNet 1,000 ประเภท (ดาวน์โหลดอัตโนมัติครั้งแรก)
model = YOLO("yolo11n-cls.pt")

for name in ["fruits.png", "bus.jpg"]:
    r = model(name, verbose=False)[0]        # ทาย 1 ภาพ ได้ผลลัพธ์ 1 ชุด
    print("ภาพ", name)
    print("  คำตอบอันดับ 1:", r.names[r.probs.top1], " ความมั่นใจ", round(float(r.probs.top1conf), 2))
    print("  5 อันดับแรก:")
    for i in r.probs.top5:
        print("   ", r.names[i], round(float(r.probs.data[i]), 2))
    cv2.imshow(name, r.plot())               # วาดคำตอบลงบนภาพ

cv2.waitKey(0)
cv2.destroyAllWindows()
