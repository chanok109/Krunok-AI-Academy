import cv2
from ultralytics import YOLO

model = YOLO("runs/classify/emoji/weights/best.pt")   # โมเดลที่เราฝึกเอง
cap = cv2.VideoCapture(0)
if not cap.isOpened():
    print("เปิดกล้องไม่ได้")
    raise SystemExit

while True:
    ok, frame = cap.read()
    if not ok:
        break
    r = model(frame, verbose=False)[0]
    name = r.names[r.probs.top1]
    conf = float(r.probs.top1conf)
    color = (0, 200, 0) if conf >= 0.7 else (0, 165, 255)   # มั่นใจน้อยใช้สีส้ม
    cv2.putText(frame, name + " " + str(round(conf, 2)), (10, 40),
                cv2.FONT_HERSHEY_SIMPLEX, 1.2, color, 3)
    cv2.imshow("Classifier", frame)
    if cv2.waitKey(1) & 0xFF == ord("q"):
        break

cap.release()
cv2.destroyAllWindows()
