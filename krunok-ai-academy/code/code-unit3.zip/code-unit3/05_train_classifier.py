from ultralytics import YOLO

# เริ่มจากโมเดลที่ฝึกไว้แล้ว แล้วสอนต่อด้วยภาพของเราเอง (Transfer Learning)
model = YOLO("yolo11n-cls.pt")
model.train(
    data="dataset",     # โฟลเดอร์ที่มี train/ และ val/ แยกโฟลเดอร์ตามชื่อประเภท
    epochs=10,          # ดูภาพชุดฝึกครบ 10 รอบ
    imgsz=224,          # ย่อภาพเป็น 224 x 224 ก่อนส่งเข้าโมเดล
    batch=16,
    device="cpu",
    name="emoji")

metrics = model.val()                      # วัดผลกับชุดตรวจสอบ (val)
print("ความแม่นยำ top-1:", round(metrics.top1, 3))
print("ไฟล์โมเดล:", model.trainer.best)
